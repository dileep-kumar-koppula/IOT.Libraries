// ArduinoJson - https://arduinojson.org
// Copyright © 2014-2022, Benoit BLANCHON
// MIT License

#pragma once

#define ARDUINOJSON_VERSION "6.19.4"
#define ARDUINOJSON_VERSION_MAJOR 6
#define ARDUINOJSON_VERSION_MINOR 19
#define ARDUINOJSON_VERSION_REVISION 4
